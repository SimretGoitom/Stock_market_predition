from stockdata.app import resources
from stockdata.app import config.py

import os

resources.drop_all()
