tickers="['AAPL', 'MSFT','TSLA','DELL','DIS']"
startDate="2018-01-01"
endDate="2019-09-01"